# Dokumentasjon
### 1/2 CSS Flexbox
Alt av bilder blir plassert ved hjelp av flexbox layout. Den sentrerer alle elementene og lager flere rader hvis nødvendig. Hvert element har en max size, så jo større skjerm du har jo mindre rader trenger du. 
Andre regler er lagt til for å størrelse, farger og bakgrunn. I tillegg animasjon for bildene. 

### 3 Javascript 
Alle bildene i poster seksjonen får endret klasse fra "hide" til "show" som gjør dem synlig. Dette skjer når brukeren har skrollet ned til bildets posisjon. I seksjon tre er det lagt til et interval som bytter bildet som blir vist hvert tredje sekund.

### 5 HTML Validator
Gyldig html fil. Sjekket med https://validator.w3.org/
Alt av funksjoner fungerer på nyeste versjoner av chrome, ie, firefox, opera og safari.
Siden er ikke testet på mobil.